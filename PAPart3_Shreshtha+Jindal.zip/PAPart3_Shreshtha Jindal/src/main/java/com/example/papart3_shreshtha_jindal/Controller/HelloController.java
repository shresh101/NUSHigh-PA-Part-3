package com.example.papart3_shreshtha_jindal.Controller;
import com.example.papart3_shreshtha_jindal.HelloApplication;
import com.example.papart3_shreshtha_jindal.Model.*;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.shape.Line;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Optional;
import java.util.Scanner;

public class HelloController {

    // Note that you MUST use the same Scanner object (input) to retrieve ALL user inputs for autograding purposes
    // ** Not using the same Scanner object will cause the autograder to fail
    // You are allowed to rename the below Scanner object for your convenience
    private static Scanner i = new Scanner(System.in);

    // Start writing your code below this comment
    // You may want to add some "global" variables here

    @FXML
    private Button aboutMe;
    @FXML
    private Button categoryButton;
    @FXML
    private Button checkoutButton;
    @FXML
    private Button doRedeemButton;
    @FXML
    private Label furnitureLabel;
    @FXML
    private Button loginButton;
    @FXML
    private Label nameLabel;
    @FXML
    private Label newPoints;
    @FXML
    private Label numItems;
    @FXML
    private Label numPoints;
    @FXML
    private TextField option;
    @FXML
    private AnchorPane optionBox;
    @FXML
    private Label optionLabel;
    @FXML
    private PasswordField password;
    @FXML
    private AnchorPane pointBox;
    @FXML
    private AnchorPane redeemBox;
    @FXML
    private Button redeemButton;
    @FXML
    private TextField redeemPoints;
    @FXML
    private Button removeItemButton;
    @FXML
    private TextArea shoppingCart;
    @FXML
    private AnchorPane shoppingCartBox;
    @FXML
    private TextArea textArea1;
    @FXML
    private TextField username;
    @FXML
    private Line line;
    @FXML
    private AnchorPane removeItemBox;
    @FXML
    private Button removeItemConfirm;
    @FXML
    private TextField removeItemOption;
    @FXML
    private Label passwordLabel;
    @FXML
    private Label usernameLabel;

    private static Security loginInfo = new Security( System.getProperty("user.dir") + "/Secure.csv");
    private static Database DB1;
    private static Account currAccount;
    private static ArrayList<Furniture> rentalCart;
    private static double deduction;
    private static double additionalCosts = 0;
    private static boolean useMover;
    private static int numCategories;
    private static int numFurnitures;
    private static double cost;
    private static boolean freeDelivery;
    private static double prevRedeemPoints = 0;
    private static int category;
    private static int warrantyIndex;
    private static int maxWarranty;
    private static double discountedPoints = 0;

    public static String warrantyMenu(double cost) {
        int options = 1;
        String s = "";
        s += ("1) No warranty" + "\n");
        if (cost >= 100) {
            options++;
            s += (options + ") Low Warranty" + "\n");
        }
        if (cost >= 250) {
            options++;
            s += (options + ") Medium Warranty" + "\n");
        }
        if (cost >= 500) {
            options++;
            s += (options + ") High Warranty" + "\n");
        }
        maxWarranty = options;
        return s;
    }

    public static char getWarranty(int option) {
        switch (option) {
            case 1:
                return 'N';
            case 2:
                return 'L';
            case 3:
                return 'M';
            case 4:
                return 'H';
        }
        return 'N';
    }

    @FXML
    void initialize() {
        optionBox.setVisible(false);
        shoppingCartBox.setVisible(false);
        pointBox.setVisible(false);
        redeemBox.setVisible(false);
        line.setVisible(false);
        nameLabel.setVisible(false);
        removeItemBox.setVisible(false);
        rentalCart = new ArrayList<Furniture>(0);
        warrantyIndex = 0;
        showShoppingCart();
        maxWarranty = 0;
        option.setText("");
        removeItemOption.setText("");
        redeemPoints.setText("");
        discountedPoints = 0;
        shoppingCartBox.setDisable(false);
    }

    public void login(ActionEvent event) {
        if (loginButton.getText().equals("Login")) {
            String loginID = username.getText();
            String loginPassword = password.getText();
            if (!loginInfo.login(loginID, loginPassword)) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error!");
                alert.setHeaderText("Invalid Login!");
                alert.setContentText("Please enter the correct username and password!");
                alert.showAndWait();
            } else {
                //setting all the constants according to account
                rentalCart = new ArrayList<Furniture>(0);
                DB1 = new Database( System.getProperty("user.dir") + "/Customer.csv",  System.getProperty("user.dir") + "/Furniture.csv",  System.getProperty("user.dir") + "/Courier.csv");
                loginInfo.login(loginID, loginPassword);
                currAccount = loginInfo.getAccount(Security.getCurrCustomerLogin());
                deduction = 0;
                //javafx stuff
                loginButton.setText("Logout");
                newPoints.setVisible(false);
                username.setEditable(false);
                password.setEditable(false);
                //setting colour of the login things to grey

                username.setStyle("-fx-text-fill: #9c9c9c");
                password.setStyle("-fx-text-fill: #9c9c9c");
                usernameLabel.setStyle("-fx-text-fill: #9c9c9c");
                passwordLabel.setStyle("-fx-text-fill: #9c9c9c");

                optionBox.setVisible(true);
                shoppingCartBox.setVisible(true);
                pointBox.setVisible(true);
                line.setVisible(true);
                nameLabel.setText("Hi " + DB1.getCustomer(currAccount.getCustomerID()).getName() + ", welcome to HIP Living");
                nameLabel.setVisible(true);
                updatePoints();

                showCategories(true);
                categoryButton.setText("Select Category");

                showCategories(true);
            }
        } else {
            loginButton.setText("Login");
            username.setStyle("-fx-text-fill: #000000");
            password.setStyle("-fx-text-fill: #000000");
            usernameLabel.setStyle("-fx-text-fill: #000000");
            passwordLabel.setStyle("-fx-text-fill: #000000");
            username.setText("");
            password.setText("");
            username.setEditable(true);
            password.setEditable(true);
            initialize();
            optionLabel.setText("Choose category: ");
            categoryButton.setText("Select category");
        }
    }

    public void chooseCategory(ActionEvent event) {
        if (categoryButton.getText().equals("Select Category")) {
            boolean intCheck = checkInt(option.getText());
            if (!intCheck) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText("Invalid Input!");
                alert.setContentText("Enter a number from 1 to " + numCategories);
                alert.showAndWait();
            } else {
                category = Integer.parseInt(option.getText());
                if (category < 1 || category > numCategories) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setHeaderText("Invalid number entered!");
                    alert.setContentText("Enter a number from 1 to " + numCategories);
                    alert.showAndWait();
                } else {
                    ArrayList<Furniture> furnitureList = DB1.getUnorderedFurnitureList(DB1.getFurnitureCategories().get(category - 1), rentalCart);
                    furnitureLabel.setText("Pick a " + DB1.getFurnitureCategories().get(category - 1) + " furniture:");
                    String furnitures = "";
                    numFurnitures = 0;
                    for (Furniture furniture : furnitureList) {
                        numFurnitures++;
                        furnitures += numFurnitures + ") " + furniture + "\n";
                    }
                    numFurnitures++;
                    furnitures += numFurnitures + ") Back to main menu";
                    textArea1.setText(furnitures);
                    categoryButton.setText("Add to cart");
                    option.setText("");
                    optionLabel.setText("Select your furniture option:");
                }
            }

        }
        else if (categoryButton.getText().equals("Add to cart")){
            boolean intCheck = checkInt(option.getText());
            if (!intCheck) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText("Invalid Input!");
                alert.setContentText("Enter a number from 1 to " + numFurnitures);
                alert.showAndWait();
            } else {
                int numEntered = Integer.parseInt(option.getText());
                if (numEntered < 1 || numEntered > numFurnitures) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setHeaderText("Invalid number entered!");
                    alert.setContentText("Enter a number from 1 to " + numFurnitures);
                    alert.showAndWait();
                }
                else{
                    showCategories(true);
                    categoryButton.setText("Select Category");
                    ArrayList<Furniture> furnitureList = DB1.getUnorderedFurnitureList(DB1.getFurnitureCategories().get(category - 1), rentalCart);
                    try {
                        rentalCart.add(furnitureList.get(numEntered - 1));
                    }
                    catch (Exception e){}
                    updateCost();
                    showShoppingCart();
                    option.setText("");
                    optionLabel.setText("Category option:");
                    updateNumItems();
                }
            }
        }
        else {
            shoppingCartBox.setDisable(true);
            boolean intCheck = checkInt(option.getText());
            if (!intCheck) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText("Invalid Input!");
                alert.setContentText("Enter a number from 1 to " + maxWarranty);
                alert.showAndWait();
            }
            int numEntered = Integer.parseInt(option.getText());
            if (numEntered < 1 || numEntered > maxWarranty) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText("Invalid number entered!");
                alert.setContentText("Enter a number from 1 to " + maxWarranty);
                alert.showAndWait();
            } else {
                if (warrantyIndex < rentalCart.size()) {
                    rentalCart.get(warrantyIndex).setWarrantyLevel(getWarranty(numEntered));
                    if (useMover) {
                        rentalCart.get(warrantyIndex).setOrderDate(new Date());
                    }
                    rentalCart.get(warrantyIndex).setOrdered(true);
                    rentalCart.get(warrantyIndex).setCustomerID(currAccount.getCustomerID());
                    warrantyIndex++;
                    if (warrantyIndex < rentalCart.size()) {
                        setNextWarranty();
                    }
                }
                if (warrantyIndex >= rentalCart.size()) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Transaction completed");
                    alert.setHeaderText("Please view your order");
                    alert.setContentText("Click on the arrow (Show details) to see details");

                    String s = "";
                    try {
                        BufferedWriter bw = new BufferedWriter(new FileWriter("Transaction.txt", true));
                        Mover mover = new Mover(0);
                        if (useMover){
                            int index = 0;
                            for (Furniture furniture: rentalCart){
                                if (index % 5 == 0){
                                    if (index != 0) {
                                        s += (mover);
                                        bw.write(mover.toString());
                                    }
                                    mover = new Mover(DB1.getNextCourier()[0], DB1.getNextCourier()[1], DB1.getNextCourier()[2]);
                                    mover.setCustomer(DB1.getCustomer(Security.getCurrCustomerLogin()));
                                }
                                mover.addMoveItems(furniture);
                                index++;
                            }
                            s += (mover);
                            bw.write(mover.toString());
                            rentalCart = new ArrayList<Furniture>(0);
                            bw.close();
                        }
                        else{
                            mover = new Mover(rentalCart.size());
                            mover.setCustomer(DB1.getCustomer(Security.getCurrCustomerLogin()));
                            s += (mover);
                            bw.write(mover + "\n");
                            for (Furniture furniture: rentalCart){
                                s += (furniture);
                                bw.write(furniture.toString() + "\n");
                            }
                            bw.close();
                            rentalCart = new ArrayList<Furniture>(0);
                        }
                    }
                    catch (IOException e){
                        System.out.println("File cannot be found");
                    }
                    rentalCart = new ArrayList<Furniture>(0);

                    currAccount.deductPoints(deduction);
                    deduction = 0;
                    updateDiscountPoints();
                    updatePoints();
                    warrantyIndex = 0;
                    DB1.writeFurniture( System.getProperty("user.dir") + "/Furniture.csv");
                    loginInfo.writeAccount( System.getProperty("user.dir") + "/Secure.csv");

                    TextArea textArea = new TextArea(s);
                    textArea.setEditable(false);
                    textArea.setWrapText(true);

                    textArea.setMaxWidth(Double.MAX_VALUE);
                    textArea.setMaxHeight(Double.MAX_VALUE);
                    GridPane.setVgrow(textArea, Priority.ALWAYS);
                    GridPane.setHgrow(textArea, Priority.ALWAYS);

                    GridPane expContent = new GridPane();
                    expContent.setMaxWidth(Double.MAX_VALUE);
                    expContent.add(textArea, 0, 0);

                    alert.getDialogPane().setExpandableContent(expContent);

                    alert.showAndWait();

                    showCategories(true);
                    categoryButton.setText("Select Category");
                    updateCost();
                    showShoppingCart();
                    option.setText("");
                    updateNumItems();
                    shoppingCartBox.setDisable(false);
                }
            }
        }
    }

    public void removeItem(ActionEvent event){
        if (rentalCart.size() > 0) {
            removeItemBox.setVisible(true);
            optionBox.setDisable(true);
            option.setEditable(false);
            checkoutButton.setDisable(true);
            doRedeemButton.setDisable(true);
            //Add this later and fix
            //option.setStyle("-fx-text-fill: #888888");
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("Shopping Cart is Empty");
            alert.setContentText("Please add items to the cart");
            alert.showAndWait();
        }
    }

    public void confirmRemove(ActionEvent event){
        String a = removeItemOption.getText();
        boolean intCheck = checkInt(a);
        if (!intCheck) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("Invalid Input!");
            alert.setContentText("Enter a number from 1 to " + rentalCart.size());
            alert.showAndWait();
        } else {
            int numEntered = Integer.parseInt(removeItemOption.getText());
            if (numEntered < 1 || numEntered > rentalCart.size()) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText("Invalid number entered!");
                alert.setContentText("Enter a number from 1 to " + rentalCart.size());
                alert.showAndWait();
            }
            else{
                rentalCart.remove(numEntered - 1);
                showShoppingCart();
                optionBox.setDisable(false);
                removeItemBox.setVisible(false);
                option.setEditable(true);
                removeItemOption.setText("");
                categoryButton.setDisable(false);
                checkoutButton.setDisable(false);
                doRedeemButton.setDisable(false);
            }
        }
    }

    public void checkOut(){
        if (rentalCart.size() == 0){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("Shopping Cart is Empty!");
            alert.setContentText("Please add items to the cart!");
            alert.showAndWait();
        }
        else{
            if (currAccount.getPoints()-deduction > 50) {
                freeDeliveryPrompt();
            }
            else{
                ButtonType yes = new ButtonType("Yes");
                ButtonType no = new ButtonType("No");
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "", yes, no);
                alert.setTitle("Paid Delivery?");
                alert.setHeaderText("Would you like to buy a delivery service?");
                alert.setContentText("$30 will be added to total cost");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == yes){
                    additionalCosts = 30;
                    showShoppingCart();
                    useMover = true;
                    confirmCheckout();
                }
                if (result.get() == no){
                    useMover = false;
                    confirmCheckout();
                }
            }

        }
    }

    public void updatePoints(){
        numPoints.setText(String.format("You have %.2f points", currAccount.getPoints()));
    }
    public void updateDiscountPoints(){
        if (deduction > 0){
            newPoints.setText(String.format("After redemption: %.2f points.", currAccount.getPoints() - deduction));
            newPoints.setVisible(true);
        }
        else {
            newPoints.setText("");
        }
    }
    public void updateNumItems(){
        numItems.setText("You have " + rentalCart.size() + " items in your shopping cart.");
    }

    public void updateCost(){
        cost = 0;
        for (Furniture f: rentalCart){
            cost += f.getCost();
        }
    }

    public void showShoppingCart(){
        String shoppingCartStr = "";
        shoppingCartStr += "Your order:\n";
        int index = 0;
        for (Furniture f: rentalCart){
            index++;
            shoppingCartStr += index + ") " + f.toString() + "\n";
        }
        updateCost();
        shoppingCartStr += String.format("-------------------------------\n" + "Total cost: $%.2f\n" + "-------------------------------\n", cost);
        if (discountedPoints > 0 || additionalCosts > 0){
            shoppingCartStr += String.format("Total cost after discount: $%.2f \n", cost * ((100 - Account.calcPercentDiscount(deduction))/100) + additionalCosts);
            shoppingCartStr += "-------------------------------\n";
        }
        shoppingCart.setText(shoppingCartStr);

    }

    public boolean checkInt(String s){
        try{
            Integer.parseInt(s);
        }
        catch(Exception e){
            return false;
        }
        return true;
    }
    public boolean checkDouble(String s){
        try{
            Double.parseDouble(s);
        }
        catch(Exception e){
            return false;
        }
        return true;
    }

    public void showCategories(boolean show){
        if (show) {
            String categories = "";
            furnitureLabel.setText("Pick a category");
            numCategories = 0;
            for (String category : DB1.getFurnitureCategories()) {
                numCategories++;
                categories += numCategories + ") " + category + "\n";
            }
            textArea1.setText(categories);
        }
        else {
            textArea1.setText("");
        }
    }

    public void redeemPoints(){
        redeemBox.setVisible(true);
        redeemPoints.setText("");
    }
    public void confirmRedeem(){
        String inputStr = redeemPoints.getText();
        if (!checkDouble(inputStr)){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Enter a number between 0 and 100");
            alert.setHeaderText("Invalid Input");
            alert.showAndWait();
        }
        else {
            double inputNum = Double.parseDouble(inputStr);
            if (inputNum < 0 || inputNum > 100){
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("Enter a number between 0 and 100");
                alert.setHeaderText("Invalid Input");
                alert.showAndWait();
            }
            else if(currAccount.getPoints() - deduction - inputNum < 0){
                /*
                I decided to make this an alert as a user might not see the text and might think that the points have been accepted and carry on but this way, the user is forced to enter a valid number.
                the code for the video is in the commented code below

                newPoints.setText(String.format("Only can redeem up to %.2f points", currAccount.getPoints()));
                newPoints.setVisible(true);

                The code above still allows the user to checkout but the user might not realise that their points are not updated making the code, in my opinion, less user friendly.
                */
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("You do not have enough points");
                alert.setHeaderText("Insufficient Points");
                alert.showAndWait();
            }
            else {
                deduction += inputNum - prevRedeemPoints;
                updateDiscountPoints();
                prevRedeemPoints = inputNum;
                discountedPoints = inputNum;
                showShoppingCart();
            }
        }
    }

    public void freeDeliveryPrompt(){
        ButtonType yes = new ButtonType("Yes");
        ButtonType no = new ButtonType("No");
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "", yes, no);
        alert.setTitle("Free Delivery?");
        alert.setHeaderText("Would you like free delivery service?");
        alert.setContentText("50 points will be redeemed.");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == yes){
            deduction += 50;
            freeDelivery = true;
            updateDiscountPoints();
            useMover = true;
            confirmCheckout();
        }
        else if(result.get() == no){
            freeDelivery = false;
            confirmCheckout();
        }
    }

    public void confirmCheckout(){
        ButtonType yes = new ButtonType("Yes");
        ButtonType no = new ButtonType("No");
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "", yes, no);
        alert.setTitle("Confirm Order?");
        alert.setHeaderText("Confirm Order?");
        alert.setContentText("");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == no){
            if (freeDelivery) {
                deduction -= 50;
                freeDelivery = false;
            }
            updateDiscountPoints();
        }
        else if(result.get() == yes){
            warranty();
        }
    }

    public void warranty(){
        //I have a feeling this code is going to make me depressed
        furnitureLabel.setText("Select warranty type");
        optionLabel.setText("Choose warranty option:");
        categoryButton.setText("Select warranty");
        option.setText("");
        shoppingCartBox.setDisable(true);
        setNextWarranty();
    }

    public void setNextWarranty(){
        String s = "";
        s += rentalCart.get(warrantyIndex) + "\n";
        s += warrantyMenu(rentalCart.get(warrantyIndex).getCost());
        textArea1.setText(s);
        option.setText("");
    }
    @FXML
    void aboutProgrammer(ActionEvent event) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("View/about-programmer.fxml"));
            Stage stage = new Stage();
            stage.setTitle("About Programmer");
            stage.setScene(new Scene(fxmlLoader.load(), 320, 240));
            stage.show();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}