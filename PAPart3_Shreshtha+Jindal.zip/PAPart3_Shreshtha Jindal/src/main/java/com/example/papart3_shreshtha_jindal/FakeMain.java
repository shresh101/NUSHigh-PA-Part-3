package com.example.papart3_shreshtha_jindal;

public class FakeMain {
    public static void main(String[] args){
        HelloApplication.main(null);}
}
