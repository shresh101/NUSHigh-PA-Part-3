package com.example.papart3_shreshtha_jindal.Model;
import java.util.*;
import java.io.*;
public class PA2MAIN {
    // You may need some other imports. Put your imports below this comment.
    // Note that you MUST use the same Scanner object (input) to retrieve ALL user inputs for autograding purposes
    // ** Not using the same Scanner object will cause the autograder to fail
    // You are allowed to rename the below Scanner object for your convenience
    private static Scanner i = new Scanner(System.in);
    // Start writing your code below this comment
    // You may want to add some "global" variables here
    private static Security loginInfo;
    private static Database DB1;
    private static Account currAccount;
    private static ArrayList<Furniture> rentalCart;
    private static double deduction;
    private static double additionalCosts;
    private static boolean useMover;
    public static void main(String[] args) {
        // Note that your code CANNOT reference any method which is NOT in the question paper
        // The autograding will use correct solutions of Database, Security and Mover based on the question paper specs
        logo();
        //Initializing Security
        loginInfo = new Security("Secure.csv");
        input1();
    }
    // You are STRONGLY ADVISED to modularise your code BY FUNCTIONALITY
    // This will help when you commence on PA3
    //DO NOT make edits to the methods from this point on.
    public static void logo(){
        System.out.println("    --   --  --  --  --  --  --  --  --  --");
        System.out.println("  --   |    | |---| |----|  --------------------------------");
        System.out.println("--   --|    |   |   |     |  -------------------------------");
        System.out.println("--   --|----|   |   |----|   ----------------  __ ----------");
        System.out.println(" --    |    |   |   |      |  | |  | | |\\ | | __  --------");
        System.out.println("   --  |    | |---| |      |__|  ||  | | \\| |__|  --------");
        System.out.println("     --  --  --  --  --  --  --  --  --  --");
        System.out.println("Welcome to HipLiving!");
    }
    public static void loginMenu(){
        System.out.println("What would you like to do?");
        System.out.println("1. Login to HipLiving.");
        System.out.println("2. Exit System.");
    }
    public static void mainMenu(){
        System.out.println();
        System.out.println("Select an option:");
        System.out.println("1. See furniture categories + Add furniture to cart.");
        System.out.println("2. View shopping cart + Remove any furniture from cart.");
        System.out.println("3. Checkout + Redeem Points.");
        System.out.println("4. Logout.");
    }
    // Helper methods to obtain warranty choice for each item.
    public static int warrantyMenu(double cost){
        int options = 1;
        System.out.println("Select an option:");
        System.out.println("1) No warranty");
        if (cost >= 100){
            options++;
            System.out.println(options + ") Low Warranty");
        }
        if (cost >= 250){
            options++;
            System.out.println(options + ") Medium Warranty");
        }
        if (cost >= 500){
            options++;
            System.out.println(options + ") High Warranty");
        }
        return options;
    }
    public static char getWarranty(int option){
        switch(option){
            case 1: return 'N';
            case 2: return 'L';
            case 3: return 'M';
            case 4: return 'H';
        }
        return 'N';
    }
    public static void input1(){
        loginMenu();
        int input = 0;
        while (input != 1 && input != 2){
            System.out.print("Enter a number above: ");
            input = inputInt();
            System.out.println();
        }
        if (input == 1) {
            //to next function
            login();
        }
        //return ans;
    }
    public static void login(){
        String loginID = "";
        String password = "";
        while (!loginInfo.login(loginID, password)) {
            System.out.print("Login ID: ");
            loginID = i.nextLine();
            System.out.print("Password: ");
            password = i.nextLine();
        }
        //To set currAccount
        loginInfo.login(loginID, password);
        currAccount = loginInfo.getAccount(Security.getCurrCustomerLogin());
        rentalCart = new ArrayList<Furniture>(0);
        DB1 = new Database("Customer.csv", "Furniture.csv", "Courier.csv");
        //to next function
        welcome();
    }
    public static void welcome(){
        //Printing out Welcome ______
        System.out.println();
        System.out.println("Welcome " + DB1.getCustomer(currAccount.getCustomerID()).getName() + "!");
        //Printing points
        System.out.printf("You have %.2f points.\n", currAccount.getPoints());
        System.out.println("You have " + rentalCart.size() + " items in your rental cart.");
        //to next function
        mainMenu();
        input2();
    }
    public static void input2(){
        System.out.print("Enter a number above: ");
        int input = inputInt();
        System.out.println();
        while (input < 1 || input > 4){
            System.out.print("Enter a number above: ");
            input = inputInt();
            System.out.println();
        }
        int nextFunction = input;
        if (nextFunction == 1) {
            seeCategories();
        }
        if (nextFunction == 2){
            viewShoppingCart();
        }
        if (nextFunction == 3){
            checkOut();
        }
        if (nextFunction == 4){
            input1();
        }
    }
    public static void seeCategories(){
        int currIndex = 0;
        for (String category: DB1.getFurnitureCategories()){
            currIndex++;
            System.out.println(currIndex + ") " + category);
        }
        System.out.print("Pick a category above: ");
        int input = inputInt();
        System.out.println();
        while (input < 1 || input > currIndex){
            System.out.print("Pick a category above: ");
            input = inputInt();
            System.out.println();
        }
        selectingAdd(input);
    }
    public static void selectingAdd(int category){
        ArrayList<Furniture> furnitureList = DB1.getUnorderedFurnitureList(DB1.getFurnitureCategories().get(category - 1), rentalCart);
        int index = 0;
        for (Furniture furniture: furnitureList){
            index++;
            System.out.println(index + ") " + furniture);
        }
        index++;
        System.out.println(index + ") Back to main menu");
        int furnitureAdd = 0;
        while (furnitureAdd < 1 || furnitureAdd > index){
            System.out.print("Enter a number above: ");
            furnitureAdd = inputInt();
            System.out.println();
        }
        if (furnitureAdd == index){
            welcome();
        }
        else {
            rentalCart.add(furnitureList.get(furnitureAdd - 1));
            System.out.println(furnitureList.get(furnitureAdd - 1).getName() + " added to cart!");
            welcome();
        }
    }
    public static void viewShoppingCart(){
        int index = 0;
        for (Furniture furniture: rentalCart){
            index++;
            System.out.println(index + ") " + furniture);
        }
        printCost(1);
        System.out.print("Do you wish to remove any items? (Y/N): ");
        String input = i.nextLine();
        input = input.toLowerCase();
        while (!input.equals("y") && !input.equals("n")){
            System.out.print("Do you wish to remove any items? (Y/N): ");
            input = i.nextLine();
        }
        if (input.equals("y")){
            if (rentalCart.size() == 0){
                System.out.println("Shopping cart is empty!");
                welcome();
            }
            else {
                removeFromCart(rentalCart.size());
            }
        }
        else{
            welcome();
        }
    }
    public static void removeFromCart(int index){
        int removeIndex = 0;
        while (removeIndex < 1 || removeIndex > index){
            System.out.print("Select Furniture: ");
            removeIndex = inputInt();
        }
        System.out.println(rentalCart.get(removeIndex - 1).getName() + " removed from cart ");
        rentalCart.remove(removeIndex - 1);
        welcome();
    }
    public static void checkOut(){
        if (rentalCart.size() == 0){
            System.out.println("Rental cart is empty!");
            System.out.println("Transaction has been completed. Please view order details ");
            welcome();
        }
        else {
            printCost(1);
            deduction = 0;
            System.out.print("Do you wish to redeem points for discount? (Y/N): ");
            String doDiscount = i.nextLine();
            doDiscount = doDiscount.toLowerCase();
            while (!doDiscount.equals("y") && !doDiscount.equals("n")){
                System.out.print("Do you wish to redeem points for discount? (Y/N): ");
                doDiscount = i.nextLine();
            }
            if (doDiscount.equals("y")) {
                discount();
            } else if (doDiscount.equals("n")) {
                System.out.println("Points remaining: %.2f" + currAccount.getPoints());
                doDelivery();
            }
        }
    }
    public static void discount(){
        double points = -1;
        while (points < 0 || points > 100){
            System.out.println("Enter how many points you wish to redeem (max 100): ");
            points = inputDouble();
            System.out.println();
        }
        deduction += points;
        currAccount.deductPoints(deduction);
        printCost(2);
        if (currAccount.getPoints() - points < 0){
            System.out.println("Insufficient points!");
            welcome();
        }
        System.out.printf("Points remaining: %.2f", (currAccount.getPoints()));
        System.out.println();
        doDelivery();
    }
    public static void doDelivery(){
        System.out.println("-------------------------------");
        useMover = false;
        if (currAccount.getPoints() >= 50) {
            System.out.print("Would you like to opt for free delivery? (50 points) (Y/N): ");
            String doFreeDelivery = i.nextLine();
            doFreeDelivery = doFreeDelivery.toLowerCase();
            while (!doFreeDelivery.equals("y") && !doFreeDelivery.equals("n")){
                System.out.print("Would you like to opt for free delivery? (50 points) (Y/N): ");
                doFreeDelivery = i.nextLine();
            }
            useMover = true;
            if (doFreeDelivery.equals("y")){
                deduction += 50;
                currAccount.deductPoints(50);
            }
            else if (doFreeDelivery.equals("n")){
                additionalCosts += 30;
            }
        }
        else {
            System.out.print("Would you like delivery service (additional $30)? (Y/N): ");
            String input = i.nextLine();
            input = input.toLowerCase();
            while (!input.equals("y") && !input.equals("n")){
                System.out.print("Would you like delivery service (additional $30)? (Y/N): ");
                input = i.nextLine();
            }
            if (input.equals("y")){
                additionalCosts += 30;
                useMover = true;
            }
        }
        confirmOrder();
    }
    public static void confirmOrder(){
        System.out.print("Confirm order? (Y/N): ");
        String confirm = i.nextLine();
        confirm = confirm.toLowerCase();
        while (!confirm.equals("y") && !confirm.equals("n")){
            System.out.print("Confirm order? (Y/N): ");
            confirm = i.nextLine();
        }
        if (confirm.equals("n")){
            welcome();
            currAccount.addPoints(deduction);
        }
        else{
            warranty();
        }
    }
    public static void warranty(){
        int input;
        int options;
        for (Furniture furniture: rentalCart) {
            input = 0;
            System.out.println(furniture);
            furniture.setOrdered(true);
            furniture.setCustomerID(currAccount.getCustomerID());
            furniture.setOrderDate(new Date());
            options = warrantyMenu(furniture.getCost());
            while (input < 1 || input > options){
                System.out.print("Enter a number above: ");
                input = inputInt();
            }
            char warrantyLevel = getWarranty(input);
            furniture.setWarrantyLevel(warrantyLevel);
            System.out.println();
        }
        pointInfo();
    }
    public static void pointInfo(){
        double cost = 0;
        for (Furniture furniture: rentalCart){
            cost += furniture.getCost();
        }
        System.out.println("-------------------------------");
        System.out.printf("Total cost after discount: $%.2f \n", cost * ((100 - Account.calcPercentDiscount(deduction))/100) + additionalCosts);
        System.out.printf("Points remaining: %.2f \n", currAccount.getPoints());
        System.out.println("-------------------------------");
        System.out.println("Transaction has been completed. Please view order details");
        moverInfo();
    }
    public static void moverInfo() {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("Transaction.txt", true));
            Mover mover = new Mover(0);
            if (useMover){
                int index = 0;
                for (Furniture furniture: rentalCart){
                    if (index % 5 == 0){
                        if (index != 0) {
                            System.out.println(mover);
                            //System.out.println(DB1.getCustomer(currAccount.getCustomerID()).toString());
                            bw.write(mover.toString());
                            //bw.write(DB1.getCustomer(currAccount.getCustomerID()).toString() + "\n");
                        }
                        mover = new Mover(DB1.getNextCourier()[0], DB1.getNextCourier()[1], DB1.getNextCourier()[2]);
                        mover.setCustomer(DB1.getCustomer(Security.getCurrCustomerLogin()));
                    }
                    mover.addMoveItems(furniture);
                    index++;
                }
                System.out.println(mover);
                bw.write(mover.toString());
                rentalCart = new ArrayList<Furniture>(0);
                bw.close();
                DB1.writeFurniture("Furniture.csv");
                loginInfo.writeAccount("Secure.csv");
                welcome();
            }
            else{
                mover = new Mover(rentalCart.size());
                mover.setCustomer(DB1.getCustomer(Security.getCurrCustomerLogin()));
                System.out.println(mover);
                bw.write(mover + "\n");
                for (Furniture furniture: rentalCart){
                    System.out.println(furniture);
                    bw.write(furniture.toString() + "\n");
                }
                bw.close();
                rentalCart = new ArrayList<Furniture>(0);
                DB1.writeFurniture("Furniture.csv");
                loginInfo.writeAccount("Secure.csv");
                welcome();
            }
        }
        catch (IOException e){
            System.out.println("File cannot be found");
        }
    }
    public static int inputInt(){
        int ans;
        try{
            ans = Integer.parseInt(i.nextLine());
        }
        catch(Exception e){
            return -1;
        }
        return ans;
    }
    public static double inputDouble(){
        double ans;
        try{
            ans = Double.parseDouble(i.nextLine());
        }
        catch(Exception e){
            return -1;
        }
        return ans;
    }
    public static void printCost(int caseX){
        double cost = 0;
        for (Furniture furniture: rentalCart){
            cost += furniture.getCost();
        }
        if (caseX == 1) {
            System.out.println("-------------------------------");
            System.out.printf("Total cost: $%.2f \n", cost);
            System.out.println("-------------------------------");
        }
        else if (caseX == 2){
            System.out.println("-------------------------------");
            System.out.printf("Total cost after discount: $%.2f \n", cost * ((100 - Account.calcPercentDiscount(deduction))/100));
            System.out.println("-------------------------------");
        }
    }
}
