module com.example.papart3_shreshtha_jindal {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.papart3_shreshtha_jindal to javafx.fxml;
    exports com.example.papart3_shreshtha_jindal;
    exports com.example.papart3_shreshtha_jindal.Controller;
    opens com.example.papart3_shreshtha_jindal.Controller to javafx.fxml;
}